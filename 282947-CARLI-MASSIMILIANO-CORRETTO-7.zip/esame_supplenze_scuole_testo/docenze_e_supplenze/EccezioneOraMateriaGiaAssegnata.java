package docenze_e_supplenze;

@SuppressWarnings("serial")
public class EccezioneOraMateriaGiaAssegnata extends Exception {

}
